from utilities import check_env_vars, set_env_vars, load_model
from matplotlib import pyplot as plt

def plot_performance(history, name_prefix:str):
    #summarize accuracy
    plt.plot(history['accuracy'])
    plt.plot(history['val_accuracy'])
    plt.title('model accuracy')
    plt.ylabel('accuracy')
    plt.xlabel('epoch')
    plt.legend(['train','test'],loc='upper left')
    plt.savefig(f'{name_prefix}_accuracy.png')

    #summarize loss
    plt.clf()
    plt.plot(history['loss'])
    plt.plot(history['val_loss'])
    plt.title('model loss')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['train','test'],loc='upper left')
    plt.savefig(f'{name_prefix}_loss.png')


if __name__ == '__main__':
    set_env_vars()
    model, history = load_model('n_5-lstm_5')
    plot_performance(history, 'test123')