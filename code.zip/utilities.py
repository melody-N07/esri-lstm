import os 
import pickle 
from keras.models import load_model as keras_load_model

def set_env_vars():
    os.environ["CUDA_VISIBLE_DEVICES"]=''
    os.environ["SM_FRAMEWORK"]='tf.keras'


def check_env_vars():
    print(f'CUDA_VISIBLE_DEVICES={os.getenv("CUDA_VISIBLE_DEVICES")}')
    print(f'SM_FRAMEWORK={os.getenv("SM_FRAMEWORK")}')
    
def save_model(model, history, name_prefix:str):
    model.save(f'{name_prefix}_model.h5')
    with open(f'{name_prefix}_history.pickle', 'wb') as f:
        pickle.dump(history, f)
        
def load_model(name_prefix:str):
    model = keras_load_model(f'{name_prefix}_model.h5')
    with open(f'{name_prefix}_history.pickle', 'rb') as f:
        history = pickle.load(f)
    return model, history

