import os
import argparse


def parse_args():
    # input and output arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, help="path to input data")
    parser.add_argument("--lstm_nodes",  type=int)
    parser.add_argument("--input_length",  type=int)
    parser.add_argument("--epochs",  type=int)
    parser.add_argument("--embedding_vector_length", required=False, type=int, default=32)
    parser.add_argument("--batch_size", required=False, type=int, default=4)
    parser.add_argument("--dropout", required=False, type=float, default=0.2)
    parser.add_argument("--validation_split", required=False, type=float, default=0.2)
    
    args = parser.parse_args()
    return args
