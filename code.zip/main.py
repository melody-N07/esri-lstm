import pandas as pd
import numpy as np
import pickle 
# import segmentation_models as sm
# import tensorflow as tf
# from tensorflow import keras
# from keras.utils import to_categorical
from tensorflow.keras.utils import to_categorical
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, LSTM, Embedding

# from keras_preprocessing.sequence import pad_sequences
# from tensorflow.keras.preprocessing.text import Tokenizer
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
from utilities import check_env_vars, set_env_vars, save_model
from parser import parse_args
import mlflow
from keras import backend
backend.clear_session()


def read_file(file_path:str, input_length:int=5):
    df = pd.read_csv(file_path, index_col=0)
    enc = OrdinalEncoder()
    enc.fit(df)
    data = enc.transform(df)
    X = data[:,:input_length]
    y = data[:,-1]
    num_classes = len(np.unique(y))
    y_encoded = to_categorical(y, num_classes=num_classes)
    X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.20, random_state=42)
    return {
        'X_train': X_train, 
        'X_test': X_test, 
        'y_train': y_train, 
        'y_test': y_test,
        'num_classes': num_classes,
    }
    

def construct_model(*,
        num_classes:int, 
        embedding_vector_length:int=32,
        input_length:int=5,
        lstm_nodes:int=50,
        dropout:float=0.0
    ):
    
    model = Sequential()
    model.add(Embedding(
        num_classes, 
        embedding_vector_length, 
        input_length=input_length,
    ))
    #drop out layer, randomly select parameter to not include, reduce complexity
    lstm=LSTM(lstm_nodes,dropout=dropout)
    model.add(lstm)

    dense = Dense(num_classes, activation='softmax')
    model.add(dense)

    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    print(model.summary())
    return model

def train_model(
        model, 
        X_train, y_train, 
        *, epochs:int=2, batch_size:int=2,validation_split=None,
        use_multiprocessing=False,
    ):
    m = model.fit(
        X_train, y_train, 
        validation_split=validation_split, 
        epochs=epochs, 
        batch_size=batch_size, 
        verbose=2, # 2 means one-line per epoch, use 0 to disable
        use_multiprocessing=use_multiprocessing,
    )
    return m.history 


def plot_performance(history, name_prefix:str):
    
    #summarize accuracy
    plt.plot(history['accuracy'])
    plt.plot(history['val_accuracy'])
    plt.title('model accuracy')
    plt.ylabel('accuracy')
    plt.xlabel('epoch')
    plt.legend(['train','test'],loc='upper left')
    plt.savefig(f'{name_prefix}_accuracy.png')

    plt.clf()
    #summarize loss
    plt.plot(history['loss'])
    plt.plot(history['val_loss'])
    plt.title('model loss')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['train','test'],loc='upper left')
    plt.savefig(f'{name_prefix}_loss.png')
    mlflow.log_figure()


if __name__=='__main__':
    set_env_vars()
    check_env_vars()
    args = parse_args()
    file_name = args.data
    lstm_nodes = args.lstm_nodes                # = 100
    input_length = args.input_length            # = 10
    epochs = args.epochs                        #=20
    embedding_vector_length = args.embedding_vector_length    #=32
    batch_size = args.batch_size                #=4 # 32?
    validation_split = args.validation_split    #=0.2 # 
    dropout = args.dropout                      # = 0.2

    name_prefix = f'n_{input_length}-lstm_{lstm_nodes}-ep_{epochs}'
    
    mlflow_experiment = 'esri-lstm'
    mlflow.set_experiment(mlflow_experiment)
    with mlflow.start_run() as run:
        mlflow.tensorflow.autolog()
        mlflow.log_params({
            'file_name':file_name,
            'input_length':input_length,
            'embedding_vector_length':embedding_vector_length,
            'lstm_nodes':lstm_nodes,
            'dropout':dropout,
        })
        
        f = read_file(file_name, input_length)
        model = construct_model(
            num_classes=f['num_classes'],
            embedding_vector_length=embedding_vector_length,
            input_length=input_length,
            lstm_nodes=lstm_nodes
        )    
        history = train_model(
            model, f['X_train'], f['y_train'],
            validation_split=validation_split,
            epochs=epochs,
            batch_size=batch_size,

        )

        # save_model(model, history, name_prefix)
    
        # plot_performance(history, name_prefix)